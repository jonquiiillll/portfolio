
document.addEventListener('DOMContentLoaded', async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const projectId = urlParams.get('id');
  const form = document.getElementById('editProjectForm');
  const cropBtn = document.getElementById('cropBtn');
  let cropper;

  const res = await fetch(`/api/projects/${projectId}`);
  const project = await res.json();

  document.getElementById('title').value = project.title;
  document.getElementById('description').value = project.description;
  document.getElementById('year').value = project.year;
  document.getElementById('category').value = project.category;

  const preview = document.getElementById('coverPreview');
  preview.src = project.coverImage;

  document.getElementById('coverImage').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      preview.src = reader.result;
      if (cropper) cropper.destroy();
      cropper = new Cropper(preview, {
        aspectRatio: 3 / 4,
        viewMode: 1,
      });
    };
    reader.readAsDataURL(file);
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('token');
    if (!token) return alert('Вы не авторизованы');

    const formData = new FormData();
    formData.append('title', document.getElementById('title').value);
    formData.append('description', document.getElementById('description').value);
    formData.append('year', document.getElementById('year').value);
    formData.append('category', document.getElementById('category').value);

    if (cropper) {
      const canvas = cropper.getCroppedCanvas({ width: 600, height: 800 });
      canvas.toBlob(blob => {
        formData.append('coverImage', blob, 'cover.jpg');
        sendUpdate();
      });
    } else {
      sendUpdate();
    }

    async function sendUpdate() {
      const res = await fetch(`/api/projects/${projectId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });

      if (res.ok) {
        alert('Проект обновлён!');
        window.location.href = '/admin.html';
      } else {
        const data = await res.json();
        alert('Ошибка: ' + data.message);
      }
    }
  });
});
