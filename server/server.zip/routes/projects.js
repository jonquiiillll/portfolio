
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Project = require('../models/Project');
const auth = require('../middleware/authMiddleware');
const router = express.Router();

const coversDir = path.join(__dirname, '..', 'uploads', 'covers');
const galleryDir = path.join(__dirname, '..', 'uploads', 'gallery');
[coversDir, galleryDir].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (file.fieldname === 'coverImage') cb(null, coversDir);
    else if (file.fieldname === 'galleryImages') cb(null, galleryDir);
    else cb(null, path.join(__dirname, '..', 'uploads'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

router.post('/', auth, upload.fields([
  { name: 'coverImage', maxCount: 1 },
  { name: 'galleryImages', maxCount: 10 }
]), async (req, res) => {
  try {
    const { title, description, category, year } = req.body;
    const coverImagePath = req.files['coverImage']
      ? `/uploads/covers/${req.files['coverImage'][0].filename}` : '';
    const galleryPaths = req.files['galleryImages']
      ? req.files['galleryImages'].map(f => `/uploads/gallery/${f.filename}`) : [];

    const newProject = new Project({
      title,
      description,
      coverImage: coverImagePath,
      galleryImages: galleryPaths,
      category,
      year: parseInt(year, 10)
    });

    await newProject.save();
    res.status(201).json(newProject);
  } catch (err) {
    res.status(500).json({ error: 'Ошибка при создании проекта' });
  }
});

router.get('/', async (req, res) => {
  try {
    const { category, year } = req.query;
    const filter = {};
    if (category && category !== 'все') filter.category = category;
    if (year) filter.year = parseInt(year, 10);
    const projects = await Project.find(filter).sort({ year: -1 });
    res.json(projects);
  } catch (err) {
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

router.get('/project/:id', async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ message: 'Не найден' });
    res.json(project);
  } catch (err) {
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

router.put('/project/:id', auth, upload.fields([{ name: 'coverImage', maxCount: 1 }]), async (req, res) => {
  try {
    const updates = {
      title: req.body.title,
      description: req.body.description,
      year: req.body.year,
      category: req.body.category
    };

    if (req.files['coverImage']) {
      updates.coverImage = `/uploads/covers/${req.files['coverImage'][0].filename}`;
    }

    const updated = await Project.findByIdAndUpdate(req.params.id, updates, { new: true });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: 'Ошибка при обновлении' });
  }
});

router.delete('/project/:id', auth, async (req, res) => {
  try {
    await Project.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка при удалении' });
  }
});

module.exports = router;
